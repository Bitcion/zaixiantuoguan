#!/bin/bash
# 失效清理
echo "Sh45_server_chan"