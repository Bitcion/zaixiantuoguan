#!/bin/bash
#copyright by hiboy
# 失效清理
echo "Sh59_trans_late"